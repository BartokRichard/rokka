"use client";

import { useState } from "react";

import ModelSelector from "../components/ModelSelector";
import { PRODUCTS, Product, MaterialOption } from "../data/products";
import ConfiguratorHeader from "./components/ConfiguratorHeader";
import MaterialSelectorView from "./views/MaterialSelectorView";
import ColorEditorView from "./views/ColorEditorView";

export default function ConfiguratorPage() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedMaterial, setSelectedMaterial] =
    useState<MaterialOption | null>(null);

  const [colorValues, setColorValues] = useState<Record<string, string>>({});
  const [fullView, setFullView] = useState(false);

  if (!selectedProduct) {
    return (
      <main className="min-h-screen w-full overflow-x-hidden bg-[#f4eee5]">
        <ModelSelector
          products={PRODUCTS}
          onSelect={(product) => {
            setSelectedProduct(product);
            setSelectedMaterial(null);
            setColorValues({});
            setFullView(false);
          }}
        />
      </main>
    );
  }

  const currentStep = selectedMaterial ? 3 : 2;

  return (
    <main className="min-h-screen w-screen overflow-x-hidden bg-[#f4eee5] text-[#20221f]">
      <ConfiguratorHeader currentStep={currentStep} />

      {!selectedMaterial ? (
        <MaterialSelectorView
          product={selectedProduct}
          onBack={() => {
            setSelectedProduct(null);
            setSelectedMaterial(null);
            setColorValues({});
            setFullView(false);
          }}
          onSelect={setSelectedMaterial}
        />
      ) : (
        <ColorEditorView
          product={selectedProduct}
          material={selectedMaterial}
          colorValues={colorValues}
          setColorValues={setColorValues}
          fullView={fullView}
          setFullView={setFullView}
          onBack={() => {
            setSelectedMaterial(null);
            setFullView(false);
          }}
        />
      )}
    </main>
  );
}
